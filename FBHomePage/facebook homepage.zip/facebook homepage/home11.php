<html>
<head>
<link type="text/css" rel="stylesheet" href="ust.css" />

</head>
<body>


<div class="header1">
<div id="img3" class="header1"><img src="logo.png" id="img3" /></div>
<div id="searcharea" class="header1"><input placeholder="search here..." type="text" id="searchbox"/></div>
<div id="profilearea" class="header1"><a href="profile.php"><img src="prof.png"id="profpic" /></a></div>
<div id="profilearea1" class="header1"><a href="profile.php">Profile</a></div>
<div id="profilearea3" class="header1">|</div>
<div id="profilearea4" class="header1">Home</div>
<div id="findf" class="header1"><img src="frn.png"height="30"/></div>
<div id="message" class="header1"><img src="chat.png"height="30"/></div>
<div id="notification" class="header1"><img src="noti.png"height="30"/></div>
<div id="profilearea2" class="header1">|</div>
<div id="setting" class="header1"><img src="set.png"height="30"/></div>
<div id="logout" class="header1"><img src="lo.png"height="30"/></div>
</div>


<div class="bodyn">
<div id="side1" class="bodyn"><img src="prof.png"id="profpic"/>Profile</div>
<div id="side2" class="bodyn">edit profile</div>
<div id="side3" class="bodyn">News feed</div>
<div id="side4" class="bodyn">Messages</div>
<div id="side5" class="bodyn">Events</div>
<div id="side6" class="bodyn">PAGES</div>
<div id="side7" class="bodyn">Pages feed</div>
<div id="side8" class="bodyn">Like pages</div>
<div id="side9" class="bodyn">Create page</div>
<div id="side10" class="bodyn">Create ad</div>
<div id="side11" class="bodyn">GROUPS</div>
<div id="side12" class="bodyn">New groups</div>
<div id="side13" class="bodyn">Create group</div>
<div id="side14" class="bodyn">APPS</div>
<div id="side15" class="bodyn">Games</div>
<div id="side16" class="bodyn">On this day</div>
<div id="side17" class="bodyn">Games feed</div>
<div id="side18" class="bodyn">FRIENDS</div>
<div id="side19" class="bodyn">Close friends</div>
<div id="side20" class="bodyn">Family</div>
<div id="side21" class="bodyn">INTERESTS</div>
<div id="side22" class="bodyn">Pages and public</div>
<div id="side23" class="bodyn">EVENTS</div>
<div id="side24" class="bodyn">Create event</div>
</div>



<div class="post00">
</div>
<div class="post10">
</div><div class="post20">
</div><div class="post30">
</div><div class="post40">
</div><div class="post50">
</div>
<div class="header0001">
</div>
<div class="sideboxxx">
</div>
<div class="sideboxxxx2">
</div>


<div class="post">
<div id="column-1" class="post">update status | add photos/videos | create photo album<hr><br><br><br><br><br><br><hr></div>
<div id="postpos" class="post"><input type="submit" id="buttonpost" value="post"/></div>
<div id="postboxpos" class="post"><textarea placeholder="What's in your mind" id="postbox" type="text"></textarea></div>

</div>

<div class="post1"><img src="prof.png"id="profpic"/><br><br><img src="wall.jpg" height="411" width="580"/><br><br><p6>Like  Comment  Share</p6><br><hr><p1>Amit Deb</p1><p2> and</p2><p1> 5 others</p1><p2> like this</p2>
<div id="post2text" class="post1"><p3>Rani Mukharji </p3><p2>with </p2><p1> Arup Pegu</p1><p2> and</p2><p1> 15 others.</p1><br><p4>4 hrs.</p4></div>
<div id="commentprof2" class="post1"><img src="prof.png"id="profpic"/></div>
<div id="commentboxpos2" class="post1"><input type="textarea" placeholder="comment" id="commentbox"/></div>
</div>

<div  class="post2"><img src="prof.png"id="profpic"/><br><br><img src="wall.jpg" height="411" width="580"/><br><br><p6>Like  Comment  Share</p6><br><hr><p1>Amit Deb</p1><p2> and</p2><p1> 5 others</p1><p2> like this</p2>
<div id="post2text" class="post2"><p3>Rani Mukharji </p3><p2>with </p2><p1> Arup Pegu</p1><p2> and</p2><p1> 15 others.</p1><br><p4>4 hrs.</p4></div>
<div id="commentprof2" class="post2"><img src="prof.png"id="profpic"/></div>
<div id="commentboxpos2" class="post2"><input type="textarea" placeholder="comment" id="commentbox"/></div>
</div>

<div class="post3"><img src="prof.png"id="profpic"/><br><br><img src="wall.jpg" height="411" width="580"/><br><br><p6>Like  Comment  Share</p6><br><hr><p1>Amit Deb</p1><p2> and</p2><p1> 5 others</p1><p2> like this</p2>
<div id="post2text" class="post2"><p3>Rani Mukharji </p3><p2>with </p2><p1> Arup Pegu</p1><p2> and</p2><p1> 15 others.</p1><br><p4>4 hrs.</p4></div>
<div id="commentprof2" class="post2"><img src="prof.png"id="profpic"/></div>
<div id="commentboxpos2" class="post2"><input type="textarea" placeholder="comment" id="commentbox"/></div>
</div>

<div class="post4"><img src="prof.png"id="profpic"/><br><br><img src="wall.jpg" height="411" width="580"/><br><br><p6>Like  Comment  Share</p6><br><hr><p1>Amit Deb</p1><p2> and</p2><p1> 5 others</p1><p2> like this</p2>
<div id="post2text" class="post2"><p3>Rani Mukharji </p3><p2>with </p2><p1> Arup Pegu</p1><p2> and</p2><p1> 15 others.</p1><br><p4>4 hrs.</p4></div>
<div id="commentprof2" class="post2"><img src="prof.png"id="profpic"/></div>
<div id="commentboxpos2" class="post2"><input type="textarea" placeholder="comment" id="commentbox"/></div>
</div>

<div class="post5"><img src="prof.png"id="profpic"/><br><br><img src="wall.jpg" height="411" width="580"/><br><br><p6>Like  Comment  Share</p6><br><hr><p1>Amit Deb</p1><p2> and</p2><p1> 5 others</p1><p2> like this</p2>
<div id="post2text" class="post2"><p3>Rani Mukharji </p3><p2>with </p2><p1> Arup Pegu</p1><p2> and</p2><p1> 15 others.</p1><br><p4>4 hrs.</p4></div>
<div id="commentprof2" class="post2"><img src="prof.png"id="profpic"/></div>
<div id="commentboxpos2" class="post2"><input type="textarea" placeholder="comment" id="commentbox"/></div>
</div>



<div class="sidebox">
<div id="sidebox1" class="sidebox">
<div id="sideboxx1">YOUR PAGES</div><hr><br><br><br>See all<hr>
<div id="sideboxx2">This Week</div><br><br><br>See more<hr>
<div id="sideboxx3">Recent Posts</div><br><br><br>See more<hr>
<div id="sideboxx4">You haven't posted in this days</div><br><br><br><br><br><br>See all
</div>
<div id="post1pos" class="sidebox"><input type="submit" id="buttonpost1" value="write a post"/></div>
</div>

<div class="sideboxxx2">
<div id="sidebox2" class="sideboxxx2">
<br>
<hr>
<div id="sideboxx21">Trending</div>
<br><br><br>See more<hr>
<div id="sideboxx22">Suggested Pages</div><br><br><br>See all<hr>
<div id="sideboxx23">People you may know</div><br><br><br><br><br><br>See all
</div>

</div>

<div class="chat-sidebarx">
</div>
<div class="chat-sidebar"><div id="chatnamebox" class="chat-sidebar">jb</div>
<div id="chatnamebox1" class="chat-sidebar">jb</div>
<div id="chatnamebox2" class="chat-sidebar">jb</div>
<div id="chatnamebox3" class="chat-sidebar">jb</div>
<div id="chatnamebox4" class="chat-sidebar">jb</div>
<div id="chatnamebox5" class="chat-sidebar">jb</div>
<div id="chatnamebox6" class="chat-sidebar">jb</div>
<div id="chatnameboxp1" class="chat-sidebar"><img src="prof.png"id="profpic"/></div>
<div id="chatnameboxp2" class="chat-sidebar"><img src="prof.png"id="profpic"/></div>
<div id="chatnameboxp3" class="chat-sidebar"><img src="prof.png"id="profpic"/></div>
<div id="chatnameboxp4" class="chat-sidebar"><img src="prof.png"id="profpic"/></div>
<div id="chatnameboxp5" class="chat-sidebar"><img src="prof.png"id="profpic"/></div>
<div id="chatnameboxp6" class="chat-sidebar"><img src="prof.png"id="profpic"/></div>
<div id="chatnameboxp7" class="chat-sidebar"><img src="prof.png"id="profpic"/></div>
</div>

<div class="header10"></div>


</body>
</html>